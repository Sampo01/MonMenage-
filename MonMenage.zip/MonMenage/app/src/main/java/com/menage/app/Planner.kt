package com.menage.app

import android.content.Context
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

object Planner {

    fun range(d: LocalDate, period: String): Pair<LocalDate, LocalDate> {
        if (period == "month") {
            return Pair(d.withDayOfMonth(1), d.withDayOfMonth(d.lengthOfMonth()))
        }
        val start = d.minusDays((d.dayOfWeek.value - 1).toLong()) // lundi
        return Pair(start, start.plusDays(6))
    }

    fun awayOn(d: LocalDate, away: List<Away>): Away? {
        val ds = d.toString()
        return away.firstOrNull { it.from <= ds && ds <= it.to }
    }

    /** Répartit régulièrement les passages d'une tâche sur les jours de présence de la période. */
    fun info(t: Task, today: LocalDate, away: List<Away>): Info {
        val ts = today.toString()
        val (start, end) = range(today, t.period)
        val rs = start.toString()
        val re = end.toString()

        val avail = mutableListOf<String>()
        var d = start
        while (!d.isAfter(end)) {
            if (awayOn(d, away) == null) avail.add(d.toString())
            d = d.plusDays(1)
        }
        val n = avail.size
        val target = minOf(t.count, n)

        val inRange = t.done.filter { it >= rs && it <= re }
        val doneToday = inRange.contains(ts)
        val doneBefore = inRange.count { it != ts }

        var should = 0
        for (k in 0 until target) {
            val slot = avail[((k + 0.5) * n / target).toInt()]
            if (slot <= ts) should++
        }
        val due = if (awayOn(today, away) != null) 0 else maxOf(0, should - doneBefore)
        return Info(due, doneToday, inRange.size, t.count)
    }

    fun todayItems(c: Context, today: LocalDate): List<Pair<Task, Info>> {
        val away = Store.away(c)
        return Store.tasks(c)
            .map { Pair(it, info(it, today, away)) }
            .filter { it.second.due > 0 || it.second.doneToday }
    }

    fun title(today: LocalDate): String =
        "Ménage du " + today.format(DateTimeFormatter.ofPattern("EEEE d MMMM", Locale.FRENCH))

    fun body(c: Context, today: LocalDate): String {
        val a = awayOn(today, Store.away(c))
        if (a != null) return "Vous êtes absent aujourd'hui. Rien au programme."
        val items = todayItems(c, today).filter { !it.second.doneToday }
        if (items.isEmpty()) return "Rien à faire aujourd'hui. Profitez-en !"
        return "À faire aujourd'hui :\n" + items.joinToString("\n") {
            "- " + it.first.name + if (it.second.due > 1) " (à rattraper)" else ""
        }
    }
}
