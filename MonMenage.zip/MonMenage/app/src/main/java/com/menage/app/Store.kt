package com.menage.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.util.UUID

object Store {
    private fun p(c: Context) = c.getSharedPreferences("menage", Context.MODE_PRIVATE)

    fun newId(): String = UUID.randomUUID().toString().take(8)

    // ---- Tâches ----
    fun tasks(c: Context): MutableList<Task> {
        val s = p(c).getString("tasks", null)
        if (s == null) {
            val seed = seedTasks()
            saveTasks(c, seed)
            return seed
        }
        val a = JSONArray(s)
        val out = mutableListOf<Task>()
        var migrated = false
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val done = mutableListOf<String>()
            val d = o.getJSONArray("done")
            for (j in 0 until d.length()) done.add(d.getString(j))
            val days = mutableListOf<Int>()
            val da = o.optJSONArray("days")
            if (da != null) for (j in 0 until da.length()) days.add(da.getInt(j))
            if (!o.has("start")) migrated = true
            out.add(
                Task(
                    o.getString("id"), o.getString("name"), o.getInt("count"), o.getString("period"),
                    days, o.optInt("minutes", 30), o.optString("afterId", ""), o.optInt("offset", 0),
                    o.optString("start", LocalDate.now().toString()), o.optInt("stagger", i % 7), done
                )
            )
        }
        if (migrated) saveTasks(c, out) // fige la date de départ des anciennes tâches
        return out
    }

    fun saveTasks(c: Context, list: List<Task>) {
        val a = JSONArray()
        for (t in list) {
            val d = JSONArray()
            for (x in t.done) d.put(x)
            val days = JSONArray()
            for (x in t.days) days.put(x)
            a.put(
                JSONObject().put("id", t.id).put("name", t.name).put("count", t.count)
                    .put("period", t.period).put("days", days).put("minutes", t.minutes)
                    .put("afterId", t.afterId).put("offset", t.offset).put("start", t.start)
                    .put("stagger", t.stagger).put("done", d)
            )
        }
        p(c).edit().putString("tasks", a.toString()).apply()
    }

    private fun seedTasks(): MutableList<Task> {
        val today = LocalDate.now().toString()
        val lessive = newId()
        return mutableListOf(
            Task(newId(), "Aspirateur", 2, "week", mutableListOf(1, 5), 45, "", 0, today, 0, mutableListOf()),
            Task(lessive, "Lancer la lessive", 2, "week", mutableListOf(0, 3), 10, "", 0, today, 0, mutableListOf()),
            Task(newId(), "Étendre le linge", 1, "week", mutableListOf(), 15, lessive, 1, today, 0, mutableListOf()),
            Task(newId(), "Salle de bain", 1, "week", mutableListOf(6), 30, "", 0, today, 0, mutableListOf()),
            Task(newId(), "Nettoyer les vitres", 1, "month", mutableListOf(5), 60, "", 0, today, 0, mutableListOf())
        )
    }

    // ---- Absences ponctuelles ----
    fun away(c: Context): MutableList<Away> {
        val s = p(c).getString("away", null) ?: return mutableListOf()
        val a = JSONArray(s)
        val out = mutableListOf<Away>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            out.add(
                Away(
                    o.getString("id"), o.getString("from"), o.getString("to"),
                    o.optString("fromTime", ""), o.optString("toTime", ""), o.optString("label", "")
                )
            )
        }
        return out
    }

    fun saveAway(c: Context, list: List<Away>) {
        val a = JSONArray()
        for (x in list) {
            a.put(
                JSONObject().put("id", x.id).put("from", x.from).put("to", x.to)
                    .put("fromTime", x.fromTime).put("toTime", x.toTime).put("label", x.label)
            )
        }
        p(c).edit().putString("away", a.toString()).apply()
    }

    // ---- Absences régulières (chaque semaine) ----
    fun weekly(c: Context): MutableList<Weekly> {
        val s = p(c).getString("weekly", null)
        if (s == null) {
            val seed = mutableListOf(
                Weekly(newId(), listOf(0, 1, 2, 3, 4), "08:00", "18:00", "Journée hors de la maison")
            )
            saveWeekly(c, seed)
            return seed
        }
        val a = JSONArray(s)
        val out = mutableListOf<Weekly>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val days = mutableListOf<Int>()
            val da = o.getJSONArray("days")
            for (j in 0 until da.length()) days.add(da.getInt(j))
            out.add(Weekly(o.getString("id"), days, o.getString("from"), o.getString("to"), o.optString("label", "")))
        }
        return out
    }

    fun saveWeekly(c: Context, list: List<Weekly>) {
        val a = JSONArray()
        for (x in list) {
            val days = JSONArray()
            for (d in x.days) days.put(d)
            a.put(
                JSONObject().put("id", x.id).put("days", days).put("from", x.from)
                    .put("to", x.to).put("label", x.label)
            )
        }
        p(c).edit().putString("weekly", a.toString()).apply()
    }

    fun planner(c: Context): Planner = Planner(tasks(c), away(c), weekly(c))

    // ---- Réglages ----
    fun phone(c: Context): String = p(c).getString("phone", "") ?: ""
    fun sms(c: Context): Boolean = p(c).getBoolean("sms", false)
    fun notif(c: Context): Boolean = p(c).getBoolean("notif", true)
    fun hour(c: Context): Int = p(c).getInt("hour", 7)
    fun minute(c: Context): Int = p(c).getInt("minute", 0)
    fun lastSent(c: Context): String = p(c).getString("lastSent", "") ?: ""

    fun saveSettings(c: Context, phone: String, sms: Boolean, notif: Boolean, hour: Int, minute: Int) {
        p(c).edit().putString("phone", phone).putBoolean("sms", sms).putBoolean("notif", notif)
            .putInt("hour", hour).putInt("minute", minute).apply()
    }

    fun setLastSent(c: Context, day: String) {
        p(c).edit().putString("lastSent", day).apply()
    }
}
