package com.menage.app

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.SmsManager
import java.time.LocalDate
import java.time.ZonedDateTime

object Notifier {
    private const val CHANNEL = "menage_daily"

    /** Envoie le message du jour (notification et/ou SMS). force = bouton de test. */
    fun send(c: Context, force: Boolean = false) {
        val today = LocalDate.now()
        if (!force && Store.lastSent(c) == today.toString()) return
        val planner = Store.planner(c)
        val title = planner.title(today)
        val body = planner.body(today)

        if (Store.notif(c)) {
            try { notify(c, title, body) } catch (e: Exception) { /* ignoré */ }
        }
        if (Store.sms(c) && Store.phone(c).isNotBlank()) {
            try { sms(c, Store.phone(c), "$title\n$body") } catch (e: Exception) { /* ignoré */ }
        }
        if (!force) Store.setLastSent(c, today.toString())
    }

    private fun notify(c: Context, title: String, body: String) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Ménage du jour", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val open = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(c, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(body.lines().first())
            .setStyle(Notification.BigTextStyle().bigText(body))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(1, n)
    }

    private fun sms(c: Context, phone: String, text: String) {
        if (c.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) return
        val sm: SmsManager = if (Build.VERSION.SDK_INT >= 31) {
            c.getSystemService(SmsManager::class.java)
        } else {
            SmsManager.getDefault()
        }
        sm.sendMultipartTextMessage(phone, null, sm.divideMessage(text), null, null)
    }

    /** Programme le prochain envoi à l'heure choisie. */
    fun schedule(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        val intent = Intent(c, AlarmReceiver::class.java).setAction("com.menage.app.DAILY")
        val pi = PendingIntent.getBroadcast(
            c, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        if (!Store.notif(c) && !Store.sms(c)) {
            am.cancel(pi)
            return
        }
        val now = ZonedDateTime.now()
        var t = now.withHour(Store.hour(c)).withMinute(Store.minute(c)).withSecond(0).withNano(0)
        if (!t.isAfter(now)) t = t.plusDays(1)
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.toInstant().toEpochMilli(), pi)
    }
}
