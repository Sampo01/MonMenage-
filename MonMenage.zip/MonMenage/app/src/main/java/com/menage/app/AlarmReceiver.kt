package com.menage.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Notifier.schedule(context)
            return
        }
        Notifier.send(context)
        Notifier.schedule(context)
    }
}
