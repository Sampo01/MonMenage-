package com.menage.app

import java.time.LocalDate
import java.time.temporal.ChronoUnit

// ---------- Modèles ----------
data class Task(
    val id: String,
    var name: String,
    var count: Int,
    var period: String,            // "week" ou "month"
    var days: MutableList<Int>,    // 0 = lundi ... 6 = dimanche ; vide = tous les jours
    var minutes: Int,
    var afterId: String,           // tâche à faire après une autre ("" si indépendante)
    var offset: Int,               // 0 = même jour, 1 = lendemain...
    var start: String,             // date de création
    var stagger: Int,              // décalage de départ pour étaler les nouvelles tâches
    val done: MutableList<String>
)

data class Away(val id: String, val from: String, val to: String, val fromTime: String, val toTime: String, val label: String)

data class Weekly(val id: String, val days: List<Int>, val from: String, val to: String, val label: String)

data class Occ(val date: LocalDate, val late: Boolean, val lateDays: Int)

data class Entry(val task: Task, val done: Boolean, val late: Boolean, val lateDays: Int)

private data class Par(val date: LocalDate, val done: Boolean)

val DAYS3 = listOf("Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim")
val DAYS_FULL = listOf("lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche")
val MONTHS = listOf(
    "janvier", "février", "mars", "avril", "mai", "juin", "juillet",
    "août", "septembre", "octobre", "novembre", "décembre"
)
val OFFSETS = listOf("le même jour", "le lendemain", "2 jours après", "3 jours après")

private const val WAKE_FROM = 7 * 60
private const val WAKE_TO = 23 * 60
private const val MIN_WIN = 15

fun hhmm(m: Int): String = "%02d:%02d".format(m / 60, m % 60)

/**
 * Planificateur : pur Kotlin, sans dépendance Android.
 * Calcule, à partir des tâches, des absences et des horaires habituels,
 * ce qu'il faut faire chaque jour.
 */
class Planner(
    private val tasks: List<Task>,
    private val away: List<Away>,
    private val weekly: List<Weekly>
) {
    private fun toMin(s: String, def: Int): Int {
        if (s.isBlank()) return def
        val p = s.split(":")
        return p[0].toInt() * 60 + (p.getOrNull(1)?.toIntOrNull() ?: 0)
    }

    /** Créneaux où vous êtes disponible ce jour-là (entre 7h et 23h), en minutes. */
    fun freeWindows(d: LocalDate): List<Pair<Int, Int>> {
        val busy = mutableListOf<Pair<Int, Int>>()
        val ds = d.toString()
        val w = d.dayOfWeek.value - 1
        for (x in weekly) {
            if (x.days.contains(w)) {
                val s = toMin(x.from, 0)
                val e = toMin(x.to, 1440)
                if (e > s) busy.add(Pair(s, e))
            }
        }
        for (a in away) {
            if (a.from <= ds && ds <= a.to) {
                val s = if (a.from == ds) toMin(a.fromTime, 0) else 0
                val e = if (a.to == ds) toMin(a.toTime, 1439) else 1440
                if (e > s) busy.add(Pair(s, e))
            }
        }
        busy.sortBy { it.first }
        val res = mutableListOf<Pair<Int, Int>>()
        var cur = WAKE_FROM
        for (b in busy) {
            if (b.first > cur) res.add(Pair(cur, minOf(b.first, WAKE_TO)))
            cur = maxOf(cur, b.second)
        }
        if (cur < WAKE_TO) res.add(Pair(cur, WAKE_TO))
        return res.filter { it.second - it.first >= MIN_WIN }
    }

    private fun usable(d: LocalDate, minutes: Int): Boolean =
        freeWindows(d).any { it.second - it.first >= minutes }

    private fun intervalOf(t: Task): Double =
        (if (t.period == "month") 28.0 else 7.0) / maxOf(1, t.count)

    /** Écart minimum entre deux passages : jamais deux jours de suite quand la tâche est espacée. */
    private fun leadOf(t: Task): Int {
        val iv = intervalOf(t)
        val b = maxOf(1, Math.floor(iv).toInt())
        val lead = if (t.days.isNotEmpty()) b - 1 else b
        return maxOf(lead, if (iv >= 2.0) 2 else 1)
    }

    private fun okDay(t: Task, d: LocalDate, ignoreDays: Boolean): Boolean {
        if (!ignoreDays && t.days.isNotEmpty() && !t.days.contains(d.dayOfWeek.value - 1)) return false
        return usable(d, t.minutes)
    }

    private fun firstOk(t: Task, from: LocalDate, ignoreDays: Boolean): LocalDate? {
        for (i in 0 until 120) {
            val d = from.plusDays(i.toLong())
            if (okDay(t, d, ignoreDays)) return d
        }
        return null
    }

    private fun daysBetween(a: LocalDate, b: LocalDate): Int = ChronoUnit.DAYS.between(a, b).toInt()

    /** Prochains passages d'une tâche indépendante, à partir d'aujourd'hui. */
    fun occIndep(t: Task, today: LocalDate, end: LocalDate): List<Occ> {
        val ts = today.toString()
        val res = mutableListOf<Occ>()
        val done = t.done.filter { it <= ts }.sorted()
        val last: LocalDate? = if (done.isNotEmpty()) LocalDate.parse(done.last()) else null
        val iv = intervalOf(t)
        val lead = leadOf(t)
        val hasDays = t.days.isNotEmpty()
        val d1: LocalDate = (if (last != null) {
            firstOk(t, last.plusDays(lead.toLong()), false)
        } else {
            val st = if (t.start.isBlank()) today else LocalDate.parse(t.start)
            firstOk(t, st.plusDays(t.stagger.toLong()), false)
        }) ?: return res

        var late = false
        var lateDays = 0
        var d: LocalDate? = d1
        if (d1.isBefore(today)) {
            late = true
            lateDays = daysBetween(d1, today)
            // en retard : on propose dès aujourd'hui, même hors des jours habituels
            d = firstOk(t, today, true)
        }
        val anchor: LocalDate? = d
        var k = 1
        while (d != null && !d.isAfter(end)) {
            res.add(Occ(d, k == 1 && late, if (k == 1) lateDays else 0))
            k++
            var next: LocalDate = d.plusDays(lead.toLong())
            if (!hasDays && anchor != null) {
                val tgt = anchor.plusDays(Math.floor((k - 1) * iv).toLong())
                if (tgt.isAfter(next)) next = tgt
            }
            d = firstOk(t, next, false)
        }
        return res
    }

    /** Tâche liée : dépend d'une autre (ex. étendre le linge le lendemain du lavage). */
    fun occFollow(t: Task, parent: Task, today: LocalDate, end: LocalDate): List<Occ> {
        val ts = today.toString()
        val lo = today.minusDays(6).toString()
        val ps = mutableListOf<Par>()
        for (x in parent.done) {
            if (x <= ts && x >= lo) ps.add(Par(LocalDate.parse(x), true))
        }
        for (o in occIndep(parent, today, end)) ps.add(Par(o.date, false))
        ps.sortBy { it.date.toEpochDay() }
        val fd = t.done.filter { it <= ts }.sorted()
        val used = HashSet<String>()
        val res = mutableListOf<Occ>()
        for (p in ps) {
            val need = p.date.plusDays(t.offset.toLong())
            val needS = need.toString()
            if (p.done) {
                var matched = false
                for (f in fd) {
                    if (!used.contains(f) && f >= needS) {
                        used.add(f)
                        matched = true
                        break
                    }
                }
                if (matched) continue
                val late = need.isBefore(today)
                val d = firstOk(t, if (late) today else need, true)
                if (d != null && !d.isAfter(end)) {
                    res.add(Occ(d, late, if (late) daysBetween(need, today) else 0))
                }
            } else {
                val d2 = firstOk(t, need, true)
                if (d2 != null && !d2.isAfter(end)) res.add(Occ(d2, false, 0))
            }
        }
        return res
    }

    private fun parentOf(t: Task): Task? {
        if (t.afterId.isBlank() || t.afterId == t.id) return null
        val p = tasks.firstOrNull { it.id == t.afterId }
        return if (p != null && p.afterId.isBlank()) p else null
    }

    fun hasParent(t: Task): Task? = parentOf(t)

    fun occ(t: Task, today: LocalDate, end: LocalDate): List<Occ> {
        val p = parentOf(t)
        return if (p != null) occFollow(t, p, today, end) else occIndep(t, today, end)
    }

    /** Planning entre deux dates : clé "AAAA-MM-JJ" -> entrées du jour. */
    fun planRange(today: LocalDate, from: LocalDate, to: LocalDate): Map<String, List<Entry>> {
        val ts = today.toString()
        val fs = from.toString()
        val es = to.toString()
        val res = HashMap<String, MutableList<Entry>>()
        for (t in tasks) {
            for (x in t.done) {
                if (x >= fs && x <= es && x <= ts) {
                    res.getOrPut(x) { mutableListOf() }.add(Entry(t, true, false, 0))
                }
            }
            for (o in occ(t, today, to)) {
                if (!o.date.isBefore(from)) {
                    res.getOrPut(o.date.toString()) { mutableListOf() }.add(Entry(t, false, o.late, o.lateDays))
                }
            }
        }
        return res
    }

    fun title(d: LocalDate): String =
        "Ménage du " + DAYS_FULL[d.dayOfWeek.value - 1] + " " + d.dayOfMonth + " " + MONTHS[d.monthValue - 1]

    fun body(today: LocalDate): String {
        val win = freeWindows(today)
        if (win.isEmpty()) return "Vous n'êtes pas disponible aujourd'hui. Rien au programme."
        val items = (planRange(today, today, today)[today.toString()] ?: emptyList()).filter { !it.done }
        if (items.isEmpty()) return "Rien à faire aujourd'hui. Profitez-en !"
        return "À faire (libre " + windowsText(win) + ") :\n" + items.joinToString("\n") {
            "- " + it.task.name + " (" + it.task.minutes + " min)" + (if (it.late) " - en retard" else "")
        }
    }

    companion object {
        fun windowsText(w: List<Pair<Int, Int>>): String =
            w.joinToString(" et ") { hhmm(it.first) + "–" + hhmm(it.second) }
    }
}
