# Mon Ménage (application Android)

Gestion de tâches ménagères avec fréquence par semaine ou par mois, périodes d'absence,
et envoi chaque jour d'une notification et/ou d'un SMS depuis le téléphone lui-même.
Couleurs beige et marron clair.

## Obtenir l'APK (gratuit, 5 minutes)
1. Sur github.com, créez un dépôt (privé si vous voulez), puis « Add file » > « Upload files ».
2. Glissez-y tout le contenu de ce dossier (y compris le dossier `.github`), puis « Commit changes ».
   Si `.github` ne se téléverse pas, créez le fichier `.github/workflows/build.yml` avec « Create new file » et collez-y le contenu.
3. Onglet **Actions** > « Compiler l'APK » > **Run workflow**. Attendez environ 3 à 5 minutes.
4. Ouvrez l'exécution terminée, téléchargez **MonMenage-apk** en bas de page, décompressez le zip : vous obtenez `app-debug.apk`.
5. Sur le téléphone : ouvrez le fichier, autorisez « installer des applications inconnues » pour votre navigateur ou gestionnaire de fichiers, puis installez.

## Premier lancement
- Onglet **Réglages** : saisissez votre numéro, choisissez notification et/ou SMS, l'heure d'envoi, puis « Enregistrer ». Acceptez les autorisations demandées.
- Utilisez « Envoyer maintenant (test) » dans l'onglet Aujourd'hui pour vérifier.
- Si le SMS est bloqué : Paramètres > Applications > Mon Ménage > menu ⋮ > « Autoriser les paramètres restreints », puis redonnez l'autorisation SMS.
- Pour une heure plus fiable : Paramètres > Batterie > Mon Ménage > « Sans restriction ».

## Limites
- L'envoi peut avoir quelques minutes de retard (économie d'énergie d'Android).
- Les SMS partent avec votre forfait (inclus dans la plupart des forfaits).
- Cette version est une version de test (signature « debug »), suffisante pour votre usage personnel.
