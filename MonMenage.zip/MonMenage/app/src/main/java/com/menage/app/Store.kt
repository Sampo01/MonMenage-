package com.menage.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Task(
    val id: String,
    var name: String,
    var count: Int,
    var period: String, // "week" ou "month"
    val done: MutableList<String>
)

data class Away(val id: String, val from: String, val to: String, val label: String)

data class Info(val due: Int, val doneToday: Boolean, val doneTotal: Int, val target: Int)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("menage", Context.MODE_PRIVATE)

    fun newId(): String = UUID.randomUUID().toString().take(8)

    // ---- Tâches ----
    fun tasks(c: Context): MutableList<Task> {
        val s = p(c).getString("tasks", null)
        if (s == null) {
            val seed = mutableListOf(
                Task(newId(), "Aspirateur", 2, "week", mutableListOf()),
                Task(newId(), "Lessive", 3, "week", mutableListOf()),
                Task(newId(), "Salle de bain", 1, "week", mutableListOf()),
                Task(newId(), "Nettoyer les vitres", 1, "month", mutableListOf()),
                Task(newId(), "Dégivrer le congélateur", 1, "month", mutableListOf())
            )
            saveTasks(c, seed)
            return seed
        }
        val a = JSONArray(s)
        val out = mutableListOf<Task>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val d = o.getJSONArray("done")
            val done = mutableListOf<String>()
            for (j in 0 until d.length()) done.add(d.getString(j))
            out.add(Task(o.getString("id"), o.getString("name"), o.getInt("count"), o.getString("period"), done))
        }
        return out
    }

    fun saveTasks(c: Context, list: List<Task>) {
        val a = JSONArray()
        for (t in list) {
            val d = JSONArray()
            for (x in t.done) d.put(x)
            a.put(
                JSONObject().put("id", t.id).put("name", t.name).put("count", t.count)
                    .put("period", t.period).put("done", d)
            )
        }
        p(c).edit().putString("tasks", a.toString()).apply()
    }

    // ---- Absences ----
    fun away(c: Context): MutableList<Away> {
        val s = p(c).getString("away", null) ?: return mutableListOf()
        val a = JSONArray(s)
        val out = mutableListOf<Away>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            out.add(Away(o.getString("id"), o.getString("from"), o.getString("to"), o.optString("label", "")))
        }
        return out
    }

    fun saveAway(c: Context, list: List<Away>) {
        val a = JSONArray()
        for (x in list) {
            a.put(JSONObject().put("id", x.id).put("from", x.from).put("to", x.to).put("label", x.label))
        }
        p(c).edit().putString("away", a.toString()).apply()
    }

    // ---- Réglages ----
    fun phone(c: Context): String = p(c).getString("phone", "") ?: ""
    fun sms(c: Context): Boolean = p(c).getBoolean("sms", false)
    fun notif(c: Context): Boolean = p(c).getBoolean("notif", true)
    fun hour(c: Context): Int = p(c).getInt("hour", 7)
    fun minute(c: Context): Int = p(c).getInt("minute", 0)
    fun lastSent(c: Context): String = p(c).getString("lastSent", "") ?: ""

    fun saveSettings(c: Context, phone: String, sms: Boolean, notif: Boolean, hour: Int, minute: Int) {
        p(c).edit().putString("phone", phone).putBoolean("sms", sms).putBoolean("notif", notif)
            .putInt("hour", hour).putInt("minute", minute).apply()
    }

    fun setLastSent(c: Context, day: String) {
        p(c).edit().putString("lastSent", day).apply()
    }
}
