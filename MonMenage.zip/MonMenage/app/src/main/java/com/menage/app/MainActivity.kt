package com.menage.app

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : Activity() {

    private val BG = Color.parseColor("#F3EBDD")
    private val SURFACE = Color.parseColor("#FBF6EC")
    private val TODAY = Color.parseColor("#EADBC1")
    private val FG = Color.parseColor("#4A3626")
    private val MUTED = Color.parseColor("#8A7461")
    private val ACCENT = Color.parseColor("#B88A5E")
    private val STRONG = Color.parseColor("#8F6440")
    private val LINE = Color.parseColor("#E3D6C0")
    private val LATE = Color.parseColor("#B5673F")
    private val ON_STRONG = Color.parseColor("#FFFAF0")

    private lateinit var content: LinearLayout
    private lateinit var tabButtons: List<Button>
    private var tab = 0
    private var editTaskId: String? = null

    // Brouillons des formulaires (gardés quand on change une date ou une heure)
    private val wDays = mutableSetOf(0, 1, 2, 3, 4)
    private var wFrom = "08:00"
    private var wTo = "18:00"
    private var wLabel = ""
    private var awayFrom: String = LocalDate.now().toString()
    private var awayTo: String = LocalDate.now().toString()
    private var aFromT = "00:00"
    private var aToT = "23:59"
    private var awayLabel = ""
    private var setHour = 7
    private var setMinute = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        window.statusBarColor = BG
        @Suppress("DEPRECATION")
        window.navigationBarColor = BG

        setHour = Store.hour(this)
        setMinute = Store.minute(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(dp(16), dp(20), dp(16), 0)
        }
        root.addView(text("Mon Ménage", 28f, FG, true))

        val names = listOf("Aujourd'hui", "Semaine", "Tâches", "Absences", "Réglages")
        val tabRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(12), 0, dp(8))
        }
        tabButtons = names.mapIndexed { i, n ->
            Button(this).apply {
                this.text = n
                isAllCaps = false
                textSize = 13f
                minWidth = 0
                minimumWidth = 0
                setPadding(dp(14), 0, dp(14), 0)
                setOnClickListener { tab = i; render() }
            }
        }
        for (b in tabButtons) {
            tabRow.addView(b, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)
            ).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        val tabScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        tabScroll.addView(tabRow)
        root.addView(tabScroll)

        val sv = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4), 0, dp(32))
        }
        sv.addView(content)
        root.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        Notifier.schedule(this)
        render()
    }

    // ---------- Outils d'interface ----------
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun gap(h: Int = 10): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(h))
    }

    private fun card(highlight: Boolean = false): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = GradientDrawable().apply {
            setColor(if (highlight) TODAY else SURFACE)
            cornerRadius = dp(12).toFloat()
            setStroke(dp(1), if (highlight) ACCENT else LINE)
        }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(8) }
    }

    private fun button(label: String, filled: Boolean = true, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(if (filled) ON_STRONG else STRONG)
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                if (filled) setColor(STRONG) else { setColor(Color.TRANSPARENT); setStroke(dp(1), ACCENT) }
            }
            setOnClickListener { onClick() }
        }

    private fun field(hint: String, value: String = "", type: Int = InputType.TYPE_CLASS_TEXT): EditText =
        EditText(this).apply {
            this.hint = hint
            setText(value)
            inputType = type
            setTextColor(FG)
            setHintTextColor(MUTED)
            backgroundTintList = ColorStateList.valueOf(ACCENT)
        }

    private fun EditText.onText(f: (String) -> Unit) {
        addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { f(s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
    }

    private fun spinner(items: List<String>, selected: Int = 0): Spinner =
        Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
            setSelection(selected.coerceIn(0, maxOf(0, items.size - 1)))
        }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun frDate(s: String): String =
        LocalDate.parse(s).format(DateTimeFormatter.ofPattern("d MMM yyyy", Locale.FRENCH))

    private fun periodWord(p: String) = if (p == "month") "mois" else "semaine"

    private fun cap(s: String) = s.replaceFirstChar { it.uppercase() }

    /** Rangée de pastilles Lun..Dim : touchez pour choisir les jours. */
    private fun dayChips(selected: MutableSet<Int>): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 0..6) {
            val tv = TextView(this).apply {
                text = DAYS3[i]
                gravity = Gravity.CENTER
                textSize = 12f
                setPadding(dp(2), dp(9), dp(2), dp(9))
            }
            fun style() {
                val on = selected.contains(i)
                tv.setTextColor(if (on) ON_STRONG else STRONG)
                tv.background = GradientDrawable().apply {
                    cornerRadius = dp(18).toFloat()
                    if (on) setColor(STRONG) else { setColor(Color.TRANSPARENT); setStroke(dp(1), ACCENT) }
                }
            }
            style()
            tv.setOnClickListener {
                if (selected.contains(i)) selected.remove(i) else selected.add(i)
                style()
            }
            row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                .apply { setMargins(dp(2), dp(4), dp(2), dp(4)) })
        }
        return row
    }

    private fun pickDate(current: String, onPicked: (String) -> Unit) {
        val d = LocalDate.parse(current)
        DatePickerDialog(this, { _, y, m, day ->
            onPicked(LocalDate.of(y, m + 1, day).toString())
        }, d.year, d.monthValue - 1, d.dayOfMonth).show()
    }

    private fun pickTime(current: String, onPicked: (String) -> Unit) {
        val p = current.split(":")
        TimePickerDialog(this, { _, h, m ->
            onPicked("%02d:%02d".format(h, m))
        }, p[0].toInt(), p.getOrNull(1)?.toIntOrNull() ?: 0, true).show()
    }

    // ---------- Navigation ----------
    private fun render() {
        content.removeAllViews()
        tabButtons.forEachIndexed { i, b ->
            val sel = i == tab
            b.setTextColor(if (sel) ON_STRONG else FG)
            b.background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(if (sel) STRONG else LINE)
            }
        }
        when (tab) {
            0 -> renderToday()
            1 -> renderWeek()
            2 -> renderTasks()
            3 -> renderAway()
            else -> renderSettings()
        }
    }

    private fun lateText(e: Entry): String =
        if (e.late) " · en retard" + (if (e.lateDays > 0) " de ${e.lateDays} j" else "") else ""

    // ---------- Aujourd'hui ----------
    private fun renderToday() {
        val today = LocalDate.now()
        val p = Store.planner(this)
        val win = p.freeWindows(today)
        content.addView(text(
            cap(today.format(DateTimeFormatter.ofPattern("EEEE d MMMM", Locale.FRENCH))), 14f, MUTED))
        content.addView(gap(8))

        val n = card()
        n.addView(text(
            if (win.isEmpty()) "Vous n'êtes pas disponible aujourd'hui."
            else "Vous êtes disponible : " + Planner.windowsText(win), 15f, FG))
        content.addView(n)

        content.addView(text("À faire aujourd'hui", 18f, FG, true))
        content.addView(gap(8))
        val items = p.planRange(today, today, today)[today.toString()] ?: emptyList()
        if (items.isEmpty()) {
            content.addView(text(
                if (win.isEmpty()) "Profitez de votre absence." else "Rien à faire aujourd'hui.", 15f, MUTED))
        }
        for (e in items) {
            val row = card()
            val cb = CheckBox(this)
            cb.text = e.task.name
            cb.textSize = 17f
            cb.setTextColor(FG)
            cb.buttonTintList = ColorStateList.valueOf(STRONG)
            cb.isChecked = e.done
            val id = e.task.id
            cb.setOnCheckedChangeListener { _, checked -> toggleDone(id, checked) }
            row.addView(cb)
            row.addView(text("${e.task.minutes} min" + lateText(e), 13f, if (e.late) LATE else MUTED))
            content.addView(row)
        }

        content.addView(gap(12))
        val msg = card()
        msg.addView(text("Message du jour", 18f, FG, true))
        msg.addView(gap(6))
        msg.addView(text(p.title(today) + "\n" + p.body(today), 14f, FG))
        msg.addView(gap(8))
        msg.addView(button("Envoyer maintenant (test)", false) {
            askPermissions()
            Notifier.send(this, true)
            toast("Message envoyé selon vos réglages")
        })
        content.addView(msg)
    }

    private fun toggleDone(id: String, checked: Boolean) {
        val ts = LocalDate.now().toString()
        val list = Store.tasks(this)
        val t = list.firstOrNull { it.id == id } ?: return
        if (checked && !t.done.contains(ts)) t.done.add(ts)
        if (!checked) t.done.remove(ts)
        Store.saveTasks(this, list)
        render()
    }

    // ---------- Semaine ----------
    private fun renderWeek() {
        val today = LocalDate.now()
        val todayKey = today.toString()
        val p = Store.planner(this)
        val mon = today.minusDays((today.dayOfWeek.value - 1).toLong())
        val sun = mon.plusDays(6)
        val plan = p.planRange(today, mon, sun)
        val fmt = DateTimeFormatter.ofPattern("d MMMM", Locale.FRENCH)
        content.addView(text("Semaine du ${mon.format(fmt)} au ${sun.format(fmt)}", 18f, FG, true))
        content.addView(gap(8))
        for (i in 0..6) {
            val d = mon.plusDays(i.toLong())
            val k = d.toString()
            val win = p.freeWindows(d)
            val list = plan[k] ?: emptyList()
            val c = card(k == todayKey)
            c.addView(text(cap(DAYS_FULL[i]) + " " + d.dayOfMonth, 16f, FG, true))
            c.addView(text(
                if (win.isEmpty()) "indisponible" else "libre " + Planner.windowsText(win), 12f, MUTED))
            c.addView(gap(4))
            if (list.isEmpty()) {
                c.addView(text(if (k < todayKey) "Rien de noté" else "Rien de prévu", 14f, MUTED))
            }
            for (e in list) {
                if (k == todayKey) {
                    val cb = CheckBox(this)
                    cb.text = e.task.name + " (${e.task.minutes} min)" + lateText(e)
                    cb.textSize = 15f
                    cb.setTextColor(if (e.late) LATE else FG)
                    cb.buttonTintList = ColorStateList.valueOf(STRONG)
                    cb.isChecked = e.done
                    val id = e.task.id
                    cb.setOnCheckedChangeListener { _, checked -> toggleDone(id, checked) }
                    c.addView(cb)
                } else {
                    val line = (if (e.done) "✓ " else "• ") + e.task.name + " (${e.task.minutes} min)" + lateText(e)
                    c.addView(text(line, 15f, if (e.done) MUTED else if (e.late) LATE else FG))
                }
            }
            content.addView(c)
        }
    }

    // ---------- Tâches ----------
    private fun describe(p: Planner, t: Task, all: List<Task>): String {
        val parent = p.hasParent(t)
        if (parent != null) {
            return "Après « ${parent.name} » (${OFFSETS[t.offset.coerceIn(0, 3)]}) · ${t.minutes} min"
        }
        val days = if (t.days.isEmpty()) "" else " · " + t.days.sorted().joinToString(", ") { DAYS_FULL[it] }
        return "${t.count} fois par ${periodWord(t.period)}$days · ${t.minutes} min"
    }

    private fun renderTasks() {
        val today = LocalDate.now()
        val all = Store.tasks(this)
        val p = Planner(all, Store.away(this), Store.weekly(this))
        val ed = editTaskId?.let { id -> all.firstOrNull { it.id == id } }

        content.addView(text("Mes tâches", 18f, FG, true))
        content.addView(gap(8))
        if (all.isEmpty()) content.addView(text("Aucune tâche. Ajoutez la première ci-dessous.", 15f, MUTED))
        for (t in all) {
            val row = card()
            row.addView(text(t.name, 17f, FG, true))
            row.addView(text(describe(p, t, all), 13f, MUTED))
            val next = p.occ(t, today, today.plusDays(60)).firstOrNull()
            row.addView(text(
                if (next == null) "Aucun créneau trouvé"
                else "Prochaine fois : " + cap(next.date.format(DateTimeFormatter.ofPattern("EEEE d MMMM", Locale.FRENCH))) +
                    (if (next.late) " (en retard de ${next.lateDays} j)" else ""),
                13f, MUTED))
            row.addView(gap(6))
            val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            btns.addView(button("Modifier", false) { editTaskId = t.id; render() })
            btns.addView(button("Supprimer", false) {
                val l = Store.tasks(this)
                l.removeAll { it.id == t.id }
                for (x in l) if (x.afterId == t.id) x.afterId = ""
                Store.saveTasks(this, l)
                if (editTaskId == t.id) editTaskId = null
                render()
            })
            row.addView(btns)
            content.addView(row)
        }

        content.addView(gap(12))
        val form = card()
        form.addView(text(if (ed != null) "Modifier la tâche" else "Ajouter une tâche", 18f, FG, true))
        val name = field("Ex. Passer la serpillière", ed?.name ?: "")
        form.addView(name)

        val parents = all.filter { it.afterId.isBlank() && it.id != ed?.id }
        val afterSp = spinner(
            listOf("Tâche indépendante") + parents.map { "Après « ${it.name} »" },
            parents.indexOfFirst { it.id == ed?.afterId } + 1
        )
        val offSp = spinner(OFFSETS, ed?.offset ?: 1)
        val count = field("Nombre de fois", (ed?.count ?: 1).toString(), InputType.TYPE_CLASS_NUMBER)
        val periodSp = spinner(listOf("Par semaine", "Par mois"), if (ed?.period == "month") 1 else 0)
        val selDays = (ed?.days ?: emptyList<Int>()).toMutableSet()
        val indep = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        indep.addView(count)
        indep.addView(periodSp)
        indep.addView(gap(6))
        indep.addView(text("Jours possibles (aucun = tous les jours)", 13f, MUTED))
        indep.addView(dayChips(selDays))
        val minutes = field("Durée (minutes)", (ed?.minutes ?: 30).toString(), InputType.TYPE_CLASS_NUMBER)

        fun sync() {
            val has = afterSp.selectedItemPosition > 0
            offSp.visibility = if (has) View.VISIBLE else View.GONE
            indep.visibility = if (has) View.GONE else View.VISIBLE
        }
        afterSp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { sync() }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        sync()

        form.addView(gap(6))
        form.addView(text("À faire après une autre tâche ?", 13f, MUTED))
        form.addView(afterSp)
        form.addView(offSp)
        form.addView(indep)
        form.addView(minutes)
        form.addView(gap(8))
        form.addView(button(if (ed != null) "Enregistrer" else "Ajouter") {
            val n = name.text.toString().trim()
            if (n.isEmpty()) { toast("Donnez un nom à la tâche"); return@button }
            val pos = afterSp.selectedItemPosition
            val afterId = if (pos > 0 && pos - 1 < parents.size) parents[pos - 1].id else ""
            val c = if (afterId.isNotEmpty()) 1 else (count.text.toString().toIntOrNull() ?: 1).coerceIn(1, 31)
            val period = if (afterId.isNotEmpty()) "week" else if (periodSp.selectedItemPosition == 1) "month" else "week"
            val days = if (afterId.isNotEmpty()) mutableListOf() else selDays.sorted().toMutableList()
            val off = if (afterId.isNotEmpty()) offSp.selectedItemPosition else 0
            val min = (minutes.text.toString().toIntOrNull() ?: 30).coerceIn(5, 240)
            val l = Store.tasks(this)
            val target = if (ed != null) l.firstOrNull { it.id == ed.id } else null
            if (target != null) {
                target.name = n; target.count = c; target.period = period; target.days = days
                target.minutes = min; target.afterId = afterId; target.offset = off
            } else {
                l.add(Task(Store.newId(), n, c, period, days, min, afterId, off,
                    LocalDate.now().toString(), l.size % 7, mutableListOf()))
            }
            Store.saveTasks(this, l)
            editTaskId = null
            render()
        })
        if (ed != null) {
            form.addView(button("Annuler", false) { editTaskId = null; render() })
        }
        content.addView(form)
    }

    // ---------- Absences ----------
    private fun renderAway() {
        // Absences régulières
        content.addView(text("Absences chaque semaine", 18f, FG, true))
        content.addView(text("Les heures où vous n'êtes pas à la maison, par exemple le travail.", 13f, MUTED))
        content.addView(gap(8))
        val weekly = Store.weekly(this)
        if (weekly.isEmpty()) content.addView(text("Aucune absence régulière.", 15f, MUTED))
        for (w in weekly) {
            val row = card()
            row.addView(text(w.days.sorted().joinToString(", ") { DAYS3[it] } + " · " + w.from + "–" + w.to, 16f, FG, true))
            if (w.label.isNotBlank()) row.addView(text(w.label, 13f, MUTED))
            row.addView(gap(6))
            row.addView(button("Supprimer", false) {
                val l = Store.weekly(this)
                l.removeAll { it.id == w.id }
                Store.saveWeekly(this, l)
                render()
            })
            content.addView(row)
        }
        val wf = card()
        wf.addView(text("Ajouter une absence régulière", 16f, FG, true))
        wf.addView(dayChips(wDays))
        wf.addView(button("De : $wFrom", false) { pickTime(wFrom) { wFrom = it; render() } })
        wf.addView(button("À : $wTo", false) { pickTime(wTo) { wTo = it; render() } })
        val wl = field("Motif (facultatif)", wLabel)
        wl.onText { wLabel = it }
        wf.addView(wl)
        wf.addView(gap(8))
        wf.addView(button("Ajouter") {
            if (wDays.isEmpty()) { toast("Choisissez au moins un jour"); return@button }
            if (wTo <= wFrom) { toast("L'heure de fin doit être après l'heure de début"); return@button }
            val l = Store.weekly(this)
            l.add(Weekly(Store.newId(), wDays.sorted(), wFrom, wTo, wLabel.trim()))
            Store.saveWeekly(this, l)
            wLabel = ""
            render()
        })
        content.addView(wf)

        // Absences ponctuelles
        content.addView(gap(12))
        content.addView(text("Absences ponctuelles", 18f, FG, true))
        content.addView(text("Vacances, week-end, soirée dehors. Pensez aux heures de départ et de retour.", 13f, MUTED))
        content.addView(gap(8))
        val list = Store.away(this).sortedBy { it.from }
        if (list.isEmpty()) content.addView(text("Aucune absence enregistrée.", 15f, MUTED))
        for (a in list) {
            val row = card()
            row.addView(text("${frDate(a.from)} ${a.fromTime} → ${frDate(a.to)} ${a.toTime}".replace("  ", " "), 15f, FG, true))
            if (a.label.isNotBlank()) row.addView(text(a.label, 13f, MUTED))
            row.addView(gap(6))
            row.addView(button("Supprimer", false) {
                val l = Store.away(this)
                l.removeAll { it.id == a.id }
                Store.saveAway(this, l)
                render()
            })
            content.addView(row)
        }

        val form = card()
        form.addView(text("Ajouter une absence ponctuelle", 16f, FG, true))
        form.addView(button("Du : ${frDate(awayFrom)}", false) {
            pickDate(awayFrom) { awayFrom = it; if (awayTo < it) awayTo = it; render() }
        })
        form.addView(button("Départ à : $aFromT", false) { pickTime(aFromT) { aFromT = it; render() } })
        form.addView(button("Au : ${frDate(awayTo)}", false) {
            pickDate(awayTo) { awayTo = it; if (awayFrom > it) awayFrom = it; render() }
        })
        form.addView(button("Retour à : $aToT", false) { pickTime(aToT) { aToT = it; render() } })
        val label = field("Motif (facultatif)", awayLabel)
        label.onText { awayLabel = it }
        form.addView(label)
        form.addView(gap(8))
        form.addView(button("Ajouter") {
            if (awayFrom == awayTo && aToT <= aFromT) {
                toast("L'heure de retour doit être après le départ"); return@button
            }
            val l = Store.away(this)
            l.add(Away(Store.newId(), awayFrom, awayTo, aFromT, aToT, awayLabel.trim()))
            Store.saveAway(this, l)
            awayLabel = ""
            render()
        })
        content.addView(form)
    }

    // ---------- Réglages ----------
    private fun renderSettings() {
        content.addView(text("Réglages d'envoi", 18f, FG, true))
        content.addView(text(
            "Chaque jour à l'heure choisie, l'application vous envoie la liste du jour.", 13f, MUTED))
        content.addView(gap(8))

        val box = card()
        val phone = field("Numéro de téléphone (SMS)", Store.phone(this), InputType.TYPE_CLASS_PHONE)
        val notif = Switch(this).apply {
            text = "Notification sur le téléphone"
            setTextColor(FG)
            isChecked = Store.notif(this@MainActivity)
        }
        val sms = Switch(this).apply {
            text = "SMS au numéro ci-dessus"
            setTextColor(FG)
            isChecked = Store.sms(this@MainActivity)
        }
        val time = button("Heure d'envoi : %02d:%02d".format(setHour, setMinute), false) {
            TimePickerDialog(this, { _, h, m ->
                setHour = h; setMinute = m; render()
            }, setHour, setMinute, true).show()
        }
        box.addView(phone)
        box.addView(gap(8))
        box.addView(notif)
        box.addView(gap(8))
        box.addView(sms)
        box.addView(gap(8))
        box.addView(time)
        box.addView(gap(8))
        box.addView(button("Enregistrer") {
            val number = phone.text.toString().trim()
            if (sms.isChecked && number.isEmpty()) { toast("Entrez un numéro pour recevoir les SMS"); return@button }
            Store.saveSettings(this, number, sms.isChecked, notif.isChecked, setHour, setMinute)
            askPermissions()
            Notifier.schedule(this)
            toast("Réglages enregistrés")
        })
        content.addView(box)
    }

    private fun askPermissions() {
        val need = mutableListOf<String>()
        if (Store.sms(this) &&
            checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.SEND_SMS)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }
}
