# Mon Ménage (application Android)

Planning de tâches ménagères sur la semaine, avec envoi chaque jour d'une notification
et/ou d'un SMS depuis le téléphone. Couleurs beige et marron clair.

## Ce que fait l'application
- **Tâches** : nombre de fois par semaine ou par mois, jours possibles (ex. mardi et samedi), durée.
- **Espacement** : jamais deux passages de suite quand la tâche est espacée (aspirateur, etc.).
- **Retard** : si une tâche n'est pas faite le jour prévu, elle est proposée dès le lendemain marquée « en retard ».
  Dès que vous la cochez, les prochains passages se recalculent à partir de ce jour-là.
- **Tâches liées** : « Étendre le linge » peut être réglé « après Lancer la lessive, le lendemain ».
- **Absences régulières** : jours et horaires (ex. lundi à vendredi de 08:00 à 18:00).
- **Absences ponctuelles** : dates et heures de départ et de retour.
- **Semaine** : vue des 7 jours avec, pour chacun, les heures où vous êtes libre et les tâches prévues.
- Une tâche n'est placée que sur un jour où vous avez un créneau libre assez long pour sa durée.

## Obtenir l'APK
1. Dans votre dépôt GitHub, remplacez le fichier `MonMenage.zip` par le nouveau (même nom).
   Gardez un seul zip dans le dépôt.
2. Onglet **Actions** > « Compiler l'APK » > **Run workflow**.
3. Téléchargez **MonMenage-apk** en bas de l'exécution terminée, décompressez, installez `app-debug.apk`
   par-dessus l'ancienne version (vos tâches sont conservées).

## Réglages
Onglet **Réglages** : numéro, notification et/ou SMS, heure d'envoi, puis « Enregistrer ».
Utilisez « Envoyer maintenant (test) » dans l'onglet Aujourd'hui pour vérifier.
- SMS bloqué : Paramètres > Applications > Mon Ménage > menu ⋮ > « Autoriser les paramètres restreints », puis redonnez l'autorisation SMS.
- Heure plus fiable : Paramètres > Batterie > Mon Ménage > « Sans restriction ».
