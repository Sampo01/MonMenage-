package com.menage.app

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : Activity() {

    private val BG = Color.parseColor("#F3EBDD")
    private val SURFACE = Color.parseColor("#FBF6EC")
    private val FG = Color.parseColor("#4A3626")
    private val MUTED = Color.parseColor("#8A7461")
    private val ACCENT = Color.parseColor("#B88A5E")
    private val STRONG = Color.parseColor("#8F6440")
    private val LINE = Color.parseColor("#E3D6C0")

    private lateinit var content: LinearLayout
    private lateinit var tabButtons: List<Button>
    private var tab = 0

    // Brouillons des formulaires
    private var awayFrom: String = LocalDate.now().toString()
    private var awayTo: String = LocalDate.now().toString()
    private var awayLabel: String = ""
    private var setHour = 7
    private var setMinute = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        window.statusBarColor = BG
        @Suppress("DEPRECATION")
        window.navigationBarColor = BG

        setHour = Store.hour(this)
        setMinute = Store.minute(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(dp(16), dp(20), dp(16), 0)
        }
        root.addView(text("Mon Ménage", 28f, FG, true))

        val tabRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(12), 0, dp(8))
        }
        val names = listOf("Aujourd'hui", "Tâches", "Absences", "Réglages")
        tabButtons = names.mapIndexed { i, n ->
            Button(this).apply {
                this.text = n
                isAllCaps = false
                textSize = 12f
                setPadding(dp(2), 0, dp(2), 0)
                setOnClickListener { tab = i; render() }
            }
        }
        for (b in tabButtons) {
            tabRow.addView(b, LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        root.addView(tabRow)

        val sv = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4), 0, dp(32))
        }
        sv.addView(content)
        root.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        Notifier.schedule(this)
        render()
    }

    // ---------- Outils d'interface ----------
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun gap(h: Int = 10): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(h))
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = GradientDrawable().apply {
            setColor(SURFACE)
            cornerRadius = dp(12).toFloat()
            setStroke(dp(1), LINE)
        }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(8) }
    }

    private fun button(label: String, filled: Boolean = true, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(if (filled) Color.parseColor("#FFFAF0") else STRONG)
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                if (filled) setColor(STRONG) else { setColor(Color.TRANSPARENT); setStroke(dp(1), ACCENT) }
            }
            setOnClickListener { onClick() }
        }

    private fun field(hint: String, value: String = "", type: Int = InputType.TYPE_CLASS_TEXT): EditText =
        EditText(this).apply {
            this.hint = hint
            setText(value)
            inputType = type
            setTextColor(FG)
            setHintTextColor(MUTED)
            backgroundTintList = ColorStateList.valueOf(ACCENT)
        }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun frDate(s: String): String =
        LocalDate.parse(s).format(DateTimeFormatter.ofPattern("d MMM yyyy", Locale.FRENCH))

    private fun periodWord(p: String) = if (p == "month") "mois" else "semaine"

    // ---------- Navigation ----------
    private fun render() {
        content.removeAllViews()
        tabButtons.forEachIndexed { i, b ->
            val sel = i == tab
            b.setTextColor(if (sel) Color.parseColor("#FFFAF0") else FG)
            b.background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(if (sel) STRONG else LINE)
            }
        }
        when (tab) {
            0 -> renderToday()
            1 -> renderTasks()
            2 -> renderAway()
            else -> renderSettings()
        }
    }

    // ---------- Aujourd'hui ----------
    private fun renderToday() {
        val today = LocalDate.now()
        content.addView(text(
            today.format(DateTimeFormatter.ofPattern("EEEE d MMMM", Locale.FRENCH)), 14f, MUTED))
        content.addView(gap(8))

        val a = Planner.awayOn(today, Store.away(this))
        if (a != null) {
            val n = card()
            n.addView(text("Vous êtes absent jusqu'au ${frDate(a.to)}. Aucune tâche aujourd'hui.", 15f, FG))
            content.addView(n)
        }

        content.addView(text("À faire aujourd'hui", 18f, FG, true))
        content.addView(gap(8))
        val items = Planner.todayItems(this, today)
        if (items.isEmpty()) {
            content.addView(text(
                if (a != null) "Profitez de votre absence." else "Tout est à jour. Rien à faire aujourd'hui.",
                15f, MUTED))
        }
        for ((t, i) in items) {
            val row = card()
            val cb = CheckBox(this)
            cb.text = t.name
            cb.textSize = 17f
            cb.setTextColor(FG)
            cb.buttonTintList = ColorStateList.valueOf(STRONG)
            cb.isChecked = i.doneToday
            cb.setOnCheckedChangeListener { _, checked -> toggleDone(t.id, checked) }
            row.addView(cb)
            val late = if (i.due > 1 && !i.doneToday) " · à rattraper" else ""
            row.addView(text(
                "${i.doneTotal} sur ${i.target} cette ${periodWord(t.period)}$late", 13f, MUTED))
            content.addView(row)
        }

        content.addView(gap(12))
        val msg = card()
        msg.addView(text("Message du jour", 18f, FG, true))
        msg.addView(gap(6))
        msg.addView(text(Planner.title(today) + "\n" + Planner.body(this, today), 14f, FG))
        msg.addView(gap(8))
        msg.addView(button("Envoyer maintenant (test)", false) {
            askPermissions()
            Notifier.send(this, true)
            toast("Message envoyé selon vos réglages")
        })
        content.addView(msg)
    }

    private fun toggleDone(id: String, checked: Boolean) {
        val ts = LocalDate.now().toString()
        val list = Store.tasks(this)
        val t = list.firstOrNull { it.id == id } ?: return
        if (checked && !t.done.contains(ts)) t.done.add(ts)
        if (!checked) t.done.remove(ts)
        Store.saveTasks(this, list)
        render()
    }

    // ---------- Tâches ----------
    private fun renderTasks() {
        val today = LocalDate.now()
        val away = Store.away(this)
        content.addView(text("Mes tâches", 18f, FG, true))
        content.addView(gap(8))
        val list = Store.tasks(this)
        if (list.isEmpty()) content.addView(text("Aucune tâche. Ajoutez la première ci-dessous.", 15f, MUTED))
        for (t in list) {
            val i = Planner.info(t, today, away)
            val row = card()
            row.addView(text(t.name, 17f, FG, true))
            row.addView(text(
                "${t.count} fois par ${periodWord(t.period)} · fait ${i.doneTotal} cette ${periodWord(t.period)}",
                13f, MUTED))
            row.addView(gap(6))
            row.addView(button("Supprimer", false) {
                val l = Store.tasks(this)
                l.removeAll { it.id == t.id }
                Store.saveTasks(this, l)
                render()
            })
            content.addView(row)
        }

        content.addView(gap(12))
        val form = card()
        form.addView(text("Ajouter une tâche", 18f, FG, true))
        val name = field("Ex. Passer la serpillière")
        val count = field("Nombre de fois", "1", InputType.TYPE_CLASS_NUMBER)
        val period = Spinner(this)
        period.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, listOf("Par semaine", "Par mois"))
        form.addView(name)
        form.addView(count)
        form.addView(period)
        form.addView(gap(8))
        form.addView(button("Ajouter") {
            val n = name.text.toString().trim()
            if (n.isEmpty()) { toast("Donnez un nom à la tâche"); return@button }
            val c = (count.text.toString().toIntOrNull() ?: 1).coerceIn(1, 31)
            val l = Store.tasks(this)
            l.add(Task(Store.newId(), n, c, if (period.selectedItemPosition == 1) "month" else "week", mutableListOf()))
            Store.saveTasks(this, l)
            render()
        })
        content.addView(form)
    }

    // ---------- Absences ----------
    private fun renderAway() {
        content.addView(text("Mes absences", 18f, FG, true))
        content.addView(text(
            "Pendant une absence, aucune tâche n'est prévue. Le planning se répartit sur les jours où vous êtes là.",
            13f, MUTED))
        content.addView(gap(8))
        val list = Store.away(this).sortedBy { it.from }
        if (list.isEmpty()) content.addView(text("Aucune absence enregistrée.", 15f, MUTED))
        for (a in list) {
            val row = card()
            row.addView(text("${frDate(a.from)} au ${frDate(a.to)}", 16f, FG, true))
            if (a.label.isNotBlank()) row.addView(text(a.label, 13f, MUTED))
            row.addView(gap(6))
            row.addView(button("Supprimer", false) {
                val l = Store.away(this)
                l.removeAll { it.id == a.id }
                Store.saveAway(this, l)
                render()
            })
            content.addView(row)
        }

        content.addView(gap(12))
        val form = card()
        form.addView(text("Ajouter une absence", 18f, FG, true))
        val label = field("Motif (facultatif)", awayLabel)
        form.addView(gap(6))
        form.addView(button("Du : ${frDate(awayFrom)}", false) {
            awayLabel = label.text.toString()
            pickDate(awayFrom) { awayFrom = it; if (awayTo < it) awayTo = it; render() }
        })
        form.addView(button("Au : ${frDate(awayTo)}", false) {
            awayLabel = label.text.toString()
            pickDate(awayTo) { awayTo = it; if (awayFrom > it) awayFrom = it; render() }
        })
        form.addView(label)
        form.addView(gap(8))
        form.addView(button("Ajouter") {
            val l = Store.away(this)
            l.add(Away(Store.newId(), awayFrom, awayTo, label.text.toString().trim()))
            Store.saveAway(this, l)
            awayLabel = ""
            render()
        })
        content.addView(form)
    }

    private fun pickDate(current: String, onPicked: (String) -> Unit) {
        val d = LocalDate.parse(current)
        DatePickerDialog(this, { _, y, m, day ->
            onPicked(LocalDate.of(y, m + 1, day).toString())
        }, d.year, d.monthValue - 1, d.dayOfMonth).show()
    }

    // ---------- Réglages ----------
    private fun renderSettings() {
        content.addView(text("Réglages d'envoi", 18f, FG, true))
        content.addView(text(
            "Chaque jour à l'heure choisie, l'application vous envoie la liste du jour.", 13f, MUTED))
        content.addView(gap(8))

        val box = card()
        val phone = field("Numéro de téléphone (SMS)", Store.phone(this), InputType.TYPE_CLASS_PHONE)
        val notif = Switch(this).apply {
            text = "Notification sur le téléphone"
            setTextColor(FG)
            isChecked = Store.notif(this@MainActivity)
        }
        val sms = Switch(this).apply {
            text = "SMS au numéro ci-dessus"
            setTextColor(FG)
            isChecked = Store.sms(this@MainActivity)
        }
        val time = button("Heure d'envoi : %02d:%02d".format(setHour, setMinute), false) {
            TimePickerDialog(this, { _, h, m ->
                setHour = h; setMinute = m; render()
            }, setHour, setMinute, true).show()
        }
        box.addView(phone)
        box.addView(gap(8))
        box.addView(notif)
        box.addView(gap(8))
        box.addView(sms)
        box.addView(gap(8))
        box.addView(time)
        box.addView(gap(8))
        box.addView(button("Enregistrer") {
            val number = phone.text.toString().trim()
            if (sms.isChecked && number.isEmpty()) { toast("Entrez un numéro pour recevoir les SMS"); return@button }
            Store.saveSettings(this, number, sms.isChecked, notif.isChecked, setHour, setMinute)
            askPermissions()
            Notifier.schedule(this)
            toast("Réglages enregistrés")
        })
        content.addView(box)
    }

    private fun askPermissions() {
        val need = mutableListOf<String>()
        if (Store.sms(this) &&
            checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.SEND_SMS)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }
}
